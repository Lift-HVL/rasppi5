from utils.logger import Logger
from utils.keyboard import KeyboardListener
import sys
import os
import time
import socket
import json

from autonomy.target_detection import TargetDetector
from autonomy.track import TargetTracker

from autopilot.mavlink_client import MAVLinkClient
from autopilot.vehicle_state import VehicleState
from autopilot.commands import AutopilotCommands

from fsm.controller import FSMController
from fsm.event_generator import EventGenerator
from fsm.event import Event
from fsm.states import State, Autonomy

from config import UPDATE_RATE

def _inject_app_telemetry(client: MAVLinkClient, fsm: FSMController, detector) -> None:
    """Send FSM/autonomy/detection state as NAMED_VALUE_FLOAT so the ground dashboard sees it."""
    client.send_named_float("fsm_state",  float(fsm.current_state.value))
    client.send_named_float("autonomy",   float(fsm.current_autonomy.value if fsm.current_autonomy else 0))
    client.send_named_float("tgt_det",    1.0 if detector.target_detected else 0.0)
    client.send_named_float("tgt_conf",   detector.target_confidence if detector.target_detected else 0.0)
    client.send_named_float("tgt_px_x",  detector.target_pixel_x if detector.target_detected else 0.0)
    client.send_named_float("tgt_bbox_h", detector.target_bbox_height if detector.target_detected else 0.0)


VEHICLE_FIELDS = [
    "connected", "last_heartbeat_time", "armed", "mode", "system_status",
    "altitude_relative_m", "altitude_absolute_m", "latitude", "longitude",
    "heading_deg", "groundspeed_m_s", "climb_rate_m_s",
    "battery_voltage_v", "battery_remaining_pct",
    "gps_fix_type", "satellites_visible", "gps_ok", "ekf_ok", "in_air",
]

def build_telemetry(vehicle_state, fsm, detector) -> dict:
    next_state = getattr(fsm, "next_state", None)
    return {
        "type": "telemetry",
        "timestamp": time.time(),
        "fsm": {
            "current_state": fsm.current_state.name,
            "next_state": next_state.name if next_state else None,
            "autonomy": fsm.current_autonomy.name if fsm.current_autonomy else None,
        },
        "vehicle": {f: getattr(vehicle_state, f, None) for f in VEHICLE_FIELDS},
        "target": {
            "detected": detector.target_detected,
            "confidence": detector.target_confidence if detector.target_detected else 0.0,
        },
    }




def main() -> None:
    print("Starting drone autonomy system...")

    GROUND_E = ("158.37.228.121", 5005)
    GROUND_K = ("192.168.1.30", 5005)
    GROUND_D = ("192.168.1.185", 5005)
       # the Mac's IP
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


    # 1 - Set up MAVLink connection
    mavlink_client = MAVLinkClient()
    mavlink_client.wait_heartbeat()

    # 2 - Shared live vehicle state
    vehicle_state = VehicleState()
    
    # 3 - Command interface to autopilot
    commands = AutopilotCommands(mavlink_client.master)

    # 4 - FSM controller
    fsm = FSMController(commands)
    
    # 5 - Event generator
    event_generator = EventGenerator()

    # 6 - Target detector and tracker
    target_detector = TargetDetector()
    tracker = TargetTracker(target_detector, commands)

    # 7 - Logger
    logger = Logger()

    # 8 - Keyboard listener (terminal input)
    keyboard = KeyboardListener()
    print("Controls: [s] start search  [l] land  [r] reset from failsafe  [q] quit")

    print("System initialized...")

    while True:
        loop_start = time.time()

        # ----------------------------------
        # 1 - Read and apply all pending MAVLink messages
        # ----------------------------------
        processed_count = 0
        while mavlink_client.update_vehicle_state(vehicle_state):
            processed_count += 1

        # ----------------------------------
        # 2 - Update target detector + handle operator keypresses
        # ----------------------------------
        target_detector.update()
        target_detector.display()

        key = keyboard.get_key()
        if key == 'q':
            break
        elif key == 's' and fsm.current_state == State.HOVER:
            print("[INPUT] START_SEARCH")
            fsm.handle_event(Event.START_SEARCH)
        elif key == 'l':
            print("[INPUT] LAND")
            fsm.handle_event(Event.LAND)
        elif key == 'r' and fsm.current_state == State.FAILSAFE:
            print("[INPUT] RESET_ON_GND")
            fsm.handle_event(Event.RESET_ON_GND)

        # ----------------------------------
        # 3 - Generate one high-level event from current data
        # ----------------------------------
        event = event_generator.generate(vehicle_state, fsm, target_detector)

        if event is not None:
            print(f"[EVENT] {event}")
            fsm.handle_event(event)

        # ----------------------------------
        # 4 - Execute autonomy behaviour for current state
        # ----------------------------------
        if target_detector.target_detected and fsm.current_state == State.AUTONOMY and fsm.current_autonomy == Autonomy.TRACK:
            if vehicle_state.mode != "GUIDED":  
                commands.guided()
            else:
                if tracker.update():
                    print("[TRACK] Target reached!")
                    fsm.handle_event(Event.TASK_COMPLETED)
            print(f"[TRACK] target={target_detector.target_position} error={target_detector.target_pixel_x - target_detector.center_x:.0f}px conf={target_detector.target_confidence:.2f}")
            
        # ----------------------------------
        # 5 - Debug output
        # ----------------------------------
        print(
            f"[STATUS] \n"
            f"fsm = {fsm.current_state.name} \n"
            f"auto = {fsm.current_autonomy.name if fsm.current_autonomy else 'None'} \n"
            f"armed = {vehicle_state.armed} \n"
            f"mode = {vehicle_state.mode} \n"
            f"alt = {vehicle_state.altitude_relative_m:.1f} m \n"
            f"gps_ok = {vehicle_state.gps_ok} \n"
            f"battery = {vehicle_state.battery_remaining_pct} % \n"
            f"target = {target_detector.target_position if target_detector.target_detected else 'None'} \n"
            f"msgs = {processed_count}"
        )
       





        # 5.5
        # 5.5 - Send status to ground station (Mac) over UDP
        status = {
            **vars(vehicle_state),
            "fsm": fsm.current_state.name,
            "autonomy": fsm.current_autonomy.name if fsm.current_autonomy else None,
            "target_detected": target_detector.target_detected,
            "target_conf": target_detector.target_confidence if target_detector.target_detected else 0.0,
        }
        
            

     

        try:
            payload = json.dumps(build_telemetry(vehicle_state, fsm, target_detector), default=str)
            sock.sendto(payload.encode(), GROUND_D)
            sock.sendto(payload.encode(), GROUND_E)

            sock.sendto(payload.encode(), GROUND_K)
        except OSError as e:
            print(f"[UDP] send failed: {e}")    

        _inject_app_telemetry(mavlink_client, fsm, target_detector)
        logger.log_iteration(vehicle_state, fsm, target_detector)

        # ----------------------------------
        # 6 - Keep loop timing stable
        # ----------------------------------
        elapsed = time.time() - loop_start
        sleep_time = max(0.0, UPDATE_RATE - elapsed)
        time.sleep(sleep_time)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("Shutting down...")
    except Exception as e:
        print(f"Error: {e}")
        raise
